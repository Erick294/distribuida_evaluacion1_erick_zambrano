package com.distribuida.servicios;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

import com.distribuida.db.Book;

@ApplicationScoped
public class ServicioBookImpl implements ServicioBook {
    @Inject
    EntityManager em;

    @Override
    public List<Book> findAll() {
        return em.createQuery("select o from Book o")
                .getResultList();
    }

    public Book findById(Integer id) {
        return em.find(Book.class, id);
    }

    public void insert(Book b) {
        var tx = em.getTransaction();

        try {
            tx.begin();
            em.persist(b);
            tx.commit();
        }
        catch(Exception ex) {
            tx.rollback();
        }
    }

    @Override
    public void delete(Integer id) {
        var tx = em.getTransaction();

        Book b = findById(id);

        try {
                    tx.begin();
                    em.remove(b);
                    tx.commit();
        } catch (Exception ex) {
            tx.rollback();       
        }
        
    }

    @Override
    public void update(Book bUp, Integer id) {
       var tx = em.getTransaction();

       Book bUpdate = findById(id);

       bUpdate.setAuthor(bUp.getAuthor());
       bUpdate.setIsbn(bUp.getIsbn());
       bUpdate.setPrice(bUp.getPrice());
       bUpdate.setTitle(bUp.getTitle());
       bUpdate.setId(id);

        try {
            tx.begin();
            em.merge(bUpdate);
            tx.commit();
        } catch (Exception ex) {
            tx.rollback();       
        }
    }
}
