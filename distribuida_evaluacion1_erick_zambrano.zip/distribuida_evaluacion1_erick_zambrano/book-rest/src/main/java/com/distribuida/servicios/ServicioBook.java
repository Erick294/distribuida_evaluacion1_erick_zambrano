package com.distribuida.servicios;

import java.util.List;

import com.distribuida.db.Book;

public interface ServicioBook {
    void insert(Book b);

    List<Book> findAll();
    Book findById(Integer id);

    void delete(Integer id);
    void update(Book b, Integer id);

}
