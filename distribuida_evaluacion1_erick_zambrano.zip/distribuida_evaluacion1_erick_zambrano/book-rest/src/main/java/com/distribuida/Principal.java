package com.distribuida;

import com.distribuida.db.Book;
import com.distribuida.servicios.ServicioBook;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;

import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;
import spark.Request;
import spark.Response;
import spark.Spark;

import java.io.IOException;
import java.util.List;

import static spark.Spark.*;

public class Principal {
    static SeContainer container;
    static Moshi moshi = new Moshi.Builder().build();
    static JsonAdapter<Book> jsonAdapter = moshi.adapter(Book.class);

    static String insertarBook(Request req, Response res){
        var servicio = container.select(ServicioBook.class).get();

        String body = req.body();
        //Book b = gson.fromJson(body, Book.class);
        try {
            Book b = jsonAdapter.fromJson(body);
            if(b==null) {
            // 404
            halt(404, "Tipo de dato incorrecto");
            return "No ingresado";
            }else{
                servicio.insert(b);
                return "Ingresado correctamente";
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
            
    }

    static List<Book> listarBooks(Request req, Response res) {
        var servicio = container.select(ServicioBook.class)
                .get();
        res.type("application/json");

        return servicio.findAll();
    }

    static Book buscarBook(Request req, Response res) {
        var servicio = container.select(ServicioBook.class)
                .get();
        res.type("application/json");

        String _id = req.params(":id");

        var book =  servicio.findById(Integer.valueOf(_id));

        if(book==null) {
            // 404
            halt(404, "Book no encontrada");
        }

        return book;
    }

    static String eliminarBook(Request req, Response res){
        var servicio = container.select(ServicioBook.class).get();

        String id = req.params(":id");
        res.type("application/json");

        var book =  servicio.findById(Integer.valueOf(id));

        if(book==null) {
            // 404
            halt(404, "Book no encontrada");
            return "Ha ocurrido un error";
        }else{
            servicio.delete(Integer.valueOf(id));
            return "Eliminado";
        }
    }

    static String actualizarBook(Request req, Response res){
        var servicio = container.select(ServicioBook.class).get();

        String body = req.body();
        String id = req.params(":id");
        res.type("application/json");

        try {
            Book b = jsonAdapter.fromJson(body);

            if(b==null) {
            // 404
            halt(404, "Ingrese a una Book");
            return "Ingrese un dato valido";
            }else{
                servicio.update(b, Integer.valueOf(id));
                return "Actualizado correctamente";
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return "";
    }

    public static void main(String[] args) {
        container = SeContainerInitializer
                .newInstance()
                .initialize();

        port(8081);

        get("/books", Principal::listarBooks);
        get("/books/:id", Principal::buscarBook);
        post("/books", Principal::insertarBook);
        delete("/books/:id", Principal::eliminarBook);
        put("/books/:id", Principal::actualizarBook);

        // Configuración CORS
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }

            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }

            return "OK";
        });

        Spark.before((request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            response.header("Access-Control-Allow-Headers", "*");
            response.type("application/json");
        });
    }
}
