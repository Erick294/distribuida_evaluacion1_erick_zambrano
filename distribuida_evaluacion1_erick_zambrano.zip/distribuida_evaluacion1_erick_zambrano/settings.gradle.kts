rootProject.name = "prog-distribuida"
include("book-rest")
